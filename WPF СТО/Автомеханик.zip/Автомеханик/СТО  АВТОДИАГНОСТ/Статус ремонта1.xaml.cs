﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace СТО__АВТОДИАГНОСТ
{
    /// <summary>
    /// Логика взаимодействия для Статус_ремонта1.xaml
    /// </summary>
    public partial class Статус_ремонта1 : Window
    {
        public Статус_ремонта1()
        {
            InitializeComponent();
        }
    }
}
